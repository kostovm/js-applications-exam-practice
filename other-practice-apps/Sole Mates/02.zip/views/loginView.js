import { html, render } from "../node_modules/lit-html/lit-html.js"
import page from "../node_modules/page/page.mjs"
import { updateNav } from "../app.js"
import { post } from "../api.js"

const loginTemplate = () => html`
<section id="login">
          <div class="form">
            <h2>Login</h2>
            <form class="login-form" @submit="${onSubmit}">
              <input type="text" name="email" id="email" placeholder="email" />
              <input
                type="password"
                name="password"
                id="password"
                placeholder="password"
              />
              <button type="submit">login</button>
              <p class="message">
                Not registered? <a href="/register">Create an account</a>
              </p>
            </form>
          </div>
        </section>
`

export async function loginView(){
    render(loginTemplate(), document.querySelector('body main'));
}

async function onSubmit(e){
    e.preventDefault();
    const formData = new FormData(e.target);
    const email = formData.get('email');
    const password = formData.get('password');

    if (email == "" || password == ""){
      alert ('All fields are required');
      throw new Error('All fields are required')
  }

    const data = await post('/users/login', {email, password});

    const userData = {
        id: data._id,
        email: data.email,
        accessToken: data.accessToken
    }
    sessionStorage.setItem('userData', JSON.stringify(userData));
    updateNav();
    page.redirect('/catalog');
}